/**
 * Login view model
 */

var app = app || {};

app.Profile = (function () {
    'use strict';

    var profileViewModel = (function () {

        var init = function () {


        };

        var show = function () {

        };

        return {
            init: init,
            show: show
        };

    }());

    return profileViewModel;

}());

