/**
 * Application Settings
 */

var appSettings = {

    everlive: {
        apiKey: 'RJSue3aSbDTAs9mX', // Put your Backend Services API key here
        scheme: 'http'
    },

    facebook: {
        // ios APP id 1497636227158422
        appId: '356956464474027', // Put your Facebook App ID here
        redirectUri: 'https://www.facebook.com/connect/login_success.html' // Put your Facebook Redirect URI here
    },

    messages: {

    }
};
